import java.util.ArrayList;
import java.util.Iterator;


public class Class_ArrayList {

	
	public static void main(String[] args) {
		
		// Create an Array list
		ArrayList<String> Colours = new ArrayList<String>();
		
		// Adding elements to Array List
		
		Colours.add("White");  
		Colours.add("Black");  
		Colours.add("Violet");
		Colours.add("Green");
		Colours.add("Blue"); 
		Colours.add("Yellow");
		Colours.add("Brown");
		Colours.add("Cream");

		//removes element at index 2
		Colours.remove(2);
		
		// Display elements	
		Iterator<String> iterator = Colours.iterator();
		
		// Display elements
		while (iterator.hasNext()) 
		{
			String element = iterator.next().toString();
			System.out.print(element + " " +"\n");
	    }
	}
}
